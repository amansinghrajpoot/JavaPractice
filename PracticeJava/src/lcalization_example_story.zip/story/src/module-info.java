module story {
	
	requires java.base;
}