package story;

import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Scanner;

public class MultiLanguageStory {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
	    String lan = sc.nextLine();
	    String country = sc.nextLine();
	    
	    Locale l = new Locale(lan, country);
	    
	    ResourceBundle r = ResourceBundle.getBundle("story/bundle",l);
		
	    String story = r.getString("story");
	    
	    System.out.println(story);
	}

}
